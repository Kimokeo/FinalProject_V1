
/*! SAMPLE
 * BANNER */

// Comment

/* Comment */

;
