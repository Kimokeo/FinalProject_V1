
// Hello world, I'm a comment!

var longNameA = 1;

var longNameB = 2;

function longFunctionC(argumentC,argumentD) {
  return longNameA + longNameB + argumentC + argumentD;
}

var result = longFunctionC(3,4);

/*! I might be preserved, yay! */

;
