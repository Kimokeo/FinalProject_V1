function longFunctionC(n,o){return longNameA+longNameB+n+o}var longNameA=1,longNameB=2,result=longFunctionC(3,4);
