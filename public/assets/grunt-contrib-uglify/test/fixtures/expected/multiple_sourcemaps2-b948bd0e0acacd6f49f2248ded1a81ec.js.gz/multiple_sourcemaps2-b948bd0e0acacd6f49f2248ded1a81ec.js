function foo(){return 42}function bar(){return 2*foo()}function baz(){return bar()*bar()}
//@ sourceMappingURL=test/fixtures/expected/multiple_sourcemaps2.mapurl
;
