function longFunctionC(argumentC,n){return longNameA+longNameB+argumentC+n}var longNameA=1,longNameB=2,result=longFunctionC(3,4);
